<link rel="stylesheet" href="<?= URL_PUBLIC ?>site/css/user.css">
<div class="container">
    <div class="login-wrapper">
        <!-- menu -->
        <div class="login-layout">

            <h3>Quên mật khẩu</h3>

            <div class="login">
                <form action="?c=account&a=quen_mat_khau" method="post">

                    <div class="form-group">
                        <label for="">
                            Nhập địa chỉ email
                        </label>
                        <input type="email" name="email" id="" class="form-controll" placeholder="email">
                    </div>

                    <button type="submit" name="btn-submit" class="button button--blue">Gửi</button>
                </form>
            </div>
        </div>

    </div>
    <!--  -->

</div>
</div>