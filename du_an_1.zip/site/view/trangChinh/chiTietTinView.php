<link rel="stylesheet" href="<?= URL_PUBLIC ?>site/css/index.css">
<link rel="stylesheet" href="<?= URL_PUBLIC ?>site/css/tintuc.css">
<div class="container">
    <div class="danhMucAll tin_tuc">
        <h2><?= $data['tinTucData'][2] ?></h2>
        <br>
        <br>
        <div>
            <?= $data['tinTucData'][3] ?>
        </div>
    </div>
</div>