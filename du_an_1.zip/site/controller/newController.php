<?php
class newController
{
    public function index(){
        view('sdf','site',[]);
    }
}