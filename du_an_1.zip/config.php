<?php
session_start();

define("URL_WEB", "http://localhost:5000");
define("URL", __DIR__);
define("URL_PUBLIC", URL_WEB . "/public/");
define("URL_ADMIN", URL . "/admin");
define("URL_SITE", URL . '/site');
