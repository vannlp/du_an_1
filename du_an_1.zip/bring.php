<?php
require_once './config.php';
require_once './core/router.php';
require_once './core/function.php';
require_once './core/DB.php';
//hello
