<footer class="footer">
    <section class="footer1">
        <div class="container">
            <div class="footer1-row">
                <div class="footer-wrapper">
                    <h3 class="footer-text-h3">Hỗ trợ khách hàng</h3>
                    <div class="footer-text">
                        <span>Hotline: </span><span class="footer-span--secondary">19001520</span><br />
                        <a href="#">Các câu hỏi thường gặp</a><br />
                        <a href="#">Gửi yêu cầu hỗ trợ</a><br />
                        <span>Hỗ trợ khách hàng: <a href="#"> hotro@lifesign.com</a></span>
                    </div>
                </div>
                <div class="footer-wrapper">
                    <h3 class="footer-text-h3">Về chúng tôi</h3>
                    <div class="footer-text">
                        <a href="#">Giới thiệu</a><br />
                        <a href="#">Quy chế hoạt động sàn thương mại điện tử</a><br />
                        <a href="#">Bán hàng cùng chúng tôi</a><br />
                    </div>
                </div>
                <div class="footer-wrapper">
                    <h3 class="footer-text-h3">Kết nối với chúng tôi</h3>
                    <div class="footer-text">
                        <a href="#" class="mxh-a"><i class="fab fa-facebook-square"></i></a>
                        <a href="#" class="mxh-a"><i class="fab fa-facebook-messenger"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer>